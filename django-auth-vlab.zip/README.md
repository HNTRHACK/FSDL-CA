# Virtual Lab: User Authentication and Authorization in Django

A Django virtual lab with Aim, Theory, Procedure, a live Simulation
(sign-up, login/logout, sessions, password hashing, @login_required,
@permission_required, groups, object-level permissions), Code, Quiz and References.

## Run locally
    pip install -r requirements-dev.txt
    python manage.py migrate
    python manage.py seed_demo        # student1 / teacher1, password Vlab@2026
    python manage.py runserver
    python manage.py test             # 14 tests

## Deploy (Render)
Push to GitHub, then on Render choose **New + -> Blueprint** and select this repo.
`render.yaml` builds, migrates, seeds the demo users and starts gunicorn.
