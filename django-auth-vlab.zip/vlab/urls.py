from django.urls import path

from . import views

urlpatterns = [
    path("", views.aim, name="aim"),
    path("theory/", views.theory, name="theory"),
    path("procedure/", views.procedure, name="procedure"),
    path("simulation/", views.simulation, name="simulation"),
    path("simulation/signup/", views.signup, name="signup"),
    path("simulation/dashboard/", views.sim_dashboard, name="sim_dashboard"),
    path("simulation/notes/new/", views.note_create, name="note_create"),
    path("simulation/notes/<int:pk>/edit/", views.note_edit, name="note_edit"),
    path("simulation/notes/<int:pk>/publish/", views.note_publish, name="note_publish"),
    path("quiz/", views.quiz, name="quiz"),
    path("code/", views.code, name="code"),
    path("references/", views.references, name="references"),
]
