from django.contrib.auth.models import Group, Permission, User
from django.core.management.base import BaseCommand

from vlab.models import LabNote


class Command(BaseCommand):
    help = "Create demo users: student1 (Students group) and teacher1 (Teachers group)."

    def handle(self, *args, **options):
        students, _ = Group.objects.get_or_create(name="Students")
        teachers, _ = Group.objects.get_or_create(name="Teachers")
        teachers.permissions.add(Permission.objects.get(codename="publish_labnote"))
        for name, group in (("student1", students), ("teacher1", teachers)):
            user, created = User.objects.get_or_create(username=name,
                                                       defaults={"email": f"{name}@somaiya.edu"})
            if created:
                user.set_password("Vlab@2026")
                user.save()
            user.groups.add(group)
        LabNote.objects.get_or_create(owner=User.objects.get(username="teacher1"),
                                      title="Welcome to the Auth lab", is_published=True,
                                      defaults={"body": "Try editing this note as student1."})
        self.stdout.write(self.style.SUCCESS("Demo users ready (password: Vlab@2026)"))
