from django.contrib import admin

from .models import LabNote


@admin.register(LabNote)
class LabNoteAdmin(admin.ModelAdmin):
    list_display = ("title", "owner", "is_published", "created_at")
    list_filter = ("is_published",)
