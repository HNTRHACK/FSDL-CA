from django.contrib.auth.models import Group, Permission, User
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from .models import LabNote

PW = "Vlab@2026"


class AuthenticationTests(TestCase):

    def test_content_pages_are_public(self):
        for name in ("aim", "theory", "procedure", "simulation", "code", "quiz", "references"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

    def test_signup_logs_user_in(self):
        resp = self.client.post(reverse("signup"), {
            "username": "hardik", "email": "hardik@somaiya.edu",
            "password1": "Strong#Pass2026", "password2": "Strong#Pass2026"})
        self.assertRedirects(resp, reverse("sim_dashboard"))
        self.assertIn("_auth_user_id", self.client.session)       # session created

    def test_weak_password_rejected(self):
        self.client.post(reverse("signup"), {"username": "w", "email": "w@x.com",
                                             "password1": "123", "password2": "123"})
        self.assertFalse(User.objects.filter(username="w").exists())

    def test_password_is_hashed(self):
        user = User.objects.create_user("h", "h@x.com", PW)
        self.assertTrue(user.password.startswith("pbkdf2_sha256$"))
        self.assertTrue(user.check_password(PW))

    def test_login_required_redirects(self):
        resp = self.client.get(reverse("sim_dashboard"))
        self.assertRedirects(resp, reverse("login") + "?next=" + reverse("sim_dashboard"))

    def test_login_and_logout(self):
        User.objects.create_user("u", "u@x.com", PW)
        resp = self.client.post(reverse("login"), {"username": "u", "password": PW})
        self.assertRedirects(resp, reverse("sim_dashboard"))
        self.client.post(reverse("logout"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_wrong_password_fails(self):
        User.objects.create_user("u", "u@x.com", PW)
        resp = self.client.post(reverse("login"), {"username": "u", "password": "wrong"})
        self.assertEqual(resp.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)


class AuthorizationTests(TestCase):

    def setUp(self):
        call_command("seed_demo", verbosity=0)
        self.student = User.objects.get(username="student1")
        self.teacher = User.objects.get(username="teacher1")

    def test_groups_and_permissions(self):
        self.assertTrue(self.teacher.has_perm("vlab.publish_labnote"))
        self.assertFalse(self.student.has_perm("vlab.publish_labnote"))
        self.assertTrue(Group.objects.get(name="Teachers").permissions.filter(
            codename="publish_labnote").exists())

    def test_student_cannot_publish(self):
        note = LabNote.objects.create(owner=self.student, title="My note")
        self.client.login(username="student1", password=PW)
        resp = self.client.get(reverse("note_publish", args=[note.pk]))
        self.assertEqual(resp.status_code, 403)
        note.refresh_from_db()
        self.assertFalse(note.is_published)

    def test_teacher_can_publish(self):
        note = LabNote.objects.create(owner=self.teacher, title="Notes")
        self.client.login(username="teacher1", password=PW)
        self.client.get(reverse("note_publish", args=[note.pk]))
        note.refresh_from_db()
        self.assertTrue(note.is_published)

    def test_dashboard_shows_permission_status(self):
        self.client.login(username="teacher1", password=PW)
        self.assertContains(self.client.get(reverse("sim_dashboard")), "vlab.publish_labnote")
        self.assertNotContains(self.client.get(reverse("sim_dashboard")), "Publish returns 403")

    def test_only_owner_can_edit(self):
        note = LabNote.objects.get(owner=self.teacher)
        self.client.login(username="student1", password=PW)
        resp = self.client.post(reverse("note_edit", args=[note.pk]), {"title": "hacked"})
        self.assertEqual(resp.status_code, 403)
        self.assertContains(resp, "You can only edit your own notes", status_code=403)

    def test_owner_can_create_and_edit(self):
        self.client.login(username="student1", password=PW)
        self.client.post(reverse("note_create"), {"title": "Draft", "body": "x"})
        note = LabNote.objects.get(title="Draft")
        self.assertEqual(note.owner, self.student)
        self.client.post(reverse("note_edit", args=[note.pk]), {"title": "Final", "body": "y"})
        note.refresh_from_db()
        self.assertEqual(note.title, "Final")

    def test_user_with_direct_permission(self):
        perm = Permission.objects.get(codename="publish_labnote")
        self.student.user_permissions.add(perm)
        self.student = User.objects.get(pk=self.student.pk)       # clear permission cache
        self.assertTrue(self.student.has_perm("vlab.publish_labnote"))


class QuizTests(TestCase):

    def test_quiz_scoring(self):
        from .views import QUIZ
        answers = {f"q{i}": str(ok) for i, (_, _, ok) in enumerate(QUIZ)}
        resp = self.client.post(reverse("quiz"), answers)
        self.assertContains(resp, f"Score: {len(QUIZ)} / {len(QUIZ)}")
