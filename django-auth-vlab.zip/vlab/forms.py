from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import LabNote


class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email")


class LabNoteForm(forms.ModelForm):
    class Meta:
        model = LabNote
        fields = ("title", "body")
