from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render

from .forms import LabNoteForm, SignUpForm
from .models import LabNote

QUIZ = [
    ("Which Django app provides users, groups and permissions?",
     ["django.contrib.sessions", "django.contrib.auth", "django.contrib.admin",
      "django.contrib.messages"], 1),
    ("What is the difference between authentication and authorization?",
     ["They are the same", "Authentication = who you are; authorization = what you may do",
      "Authentication = what you may do; authorization = who you are",
      "Authorization happens before authentication"], 1),
    ("By default, how does Django store user passwords?",
     ["Plain text", "Base64 encoded", "Salted PBKDF2-SHA256 hash", "MD5 hash"], 2),
    ("Which decorator redirects anonymous users to the login page?",
     ["@csrf_exempt", "@require_POST", "@login_required", "@cache_page"], 2),
    ("What does @permission_required('vlab.publish_labnote', raise_exception=True) do "
     "for a logged-in user without that permission?",
     ["Redirects to home", "Returns 403 Forbidden", "Returns 404", "Logs the user out"], 1),
    ("Where is the logged-in user's id kept between requests?",
     ["In a hidden form field", "In the URL", "In the session (session cookie)",
      "In the HTML title"], 2),
    ("Which function verifies a username and password against the database?",
     ["authenticate()", "login()", "check()", "verify()"], 0),
    ("Groups in Django are used to...",
     ["Store sessions", "Give a set of permissions to many users at once",
      "Group URLs", "Cache templates"], 1),
]


# ---------------- Virtual-lab content pages ----------------
def page(name):
    def view(request):
        return render(request, f"vlab/{name}.html", {"active": name})
    view.__name__ = name
    return view


aim = page("aim")
theory = page("theory")
procedure = page("procedure")
code = page("code")
references = page("references")


def simulation(request):
    return render(request, "vlab/simulation.html", {"active": "simulation"})


def quiz(request):
    result = None
    if request.method == "POST":
        answers = [request.POST.get(f"q{i}") for i in range(len(QUIZ))]
        score = sum(1 for (_, _, ok), a in zip(QUIZ, answers) if a == str(ok))
        result = {"score": score, "total": len(QUIZ), "answers": answers}
    items = [(i, q, list(enumerate(opts)), ok) for i, (q, opts, ok) in enumerate(QUIZ)]
    return render(request, "vlab/quiz.html", {"active": "quiz", "items": items, "result": result})


# ---------------- Simulation: authentication ----------------
def signup(request):
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)                       # creates the session
        messages.success(request, "Account created and logged in.")
        return redirect("sim_dashboard")
    return render(request, "registration/signup.html", {"form": form, "active": "simulation"})


@login_required
def sim_dashboard(request):
    user = request.user
    return render(request, "vlab/sim_dashboard.html", {
        "active": "simulation",
        "hash_parts": user.password.split("$"),
        "groups": [g.name for g in user.groups.all()],
        "my_perms": sorted(p for p in user.get_all_permissions() if p.startswith("vlab.")),
        "session_key": request.session.session_key,
        "session_expiry": request.session.get_expiry_age(),
        "notes": LabNote.objects.filter(owner=user),
        "published": LabNote.objects.filter(is_published=True).exclude(owner=user),
        "form": LabNoteForm(),
    })


# ---------------- Simulation: authorization ----------------
@login_required
def note_create(request):
    form = LabNoteForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        note = form.save(commit=False)
        note.owner = request.user
        note.save()
        messages.success(request, f"Note '{note.title}' saved.")
    return redirect("sim_dashboard")


@login_required
def note_edit(request, pk):
    note = get_object_or_404(LabNote, pk=pk)
    if note.owner != request.user:              # object-level authorization
        raise PermissionDenied("You can only edit your own notes.")
    form = LabNoteForm(request.POST or None, instance=note)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Note updated.")
        return redirect("sim_dashboard")
    return render(request, "vlab/note_edit.html",
                  {"form": form, "note": note, "active": "simulation"})


@login_required
@permission_required("vlab.publish_labnote", raise_exception=True)
def note_publish(request, pk):
    note = get_object_or_404(LabNote, pk=pk)
    note.is_published = True
    note.save()
    messages.success(request, f"Note '{note.title}' published.")
    return redirect("sim_dashboard")


def forbidden(request, exception=None):
    reason = str(exception or "") or "Required permission is missing (vlab.publish_labnote)."
    return render(request, "vlab/403.html", {"active": "simulation", "reason": reason},
                  status=403)
