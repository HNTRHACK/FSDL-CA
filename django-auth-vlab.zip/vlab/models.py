from django.conf import settings
from django.db import models


class LabNote(models.Model):
    """A note written by a student during the simulation.

    Used to demonstrate:
    - object-level authorization: only the owner may edit a note
    - a custom permission: only users with 'vlab.publish_labnote' may publish
    """

    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                              related_name="notes")
    title = models.CharField(max_length=120)
    body = models.TextField(blank=True)
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        permissions = [("publish_labnote", "Can publish lab notes")]

    def __str__(self):
        return self.title
